import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/Dashboard";
import NivelAgua from "./pages/NivelAgua";
import Graficos from "./pages/Graficos";
import Home from "./pages/Home";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import { AuthProvider } from "./context/AuthContext";
import Perfil from "./pages/Perfil";
import "./App.css";

function NavbarWrapper() {
  const location = useLocation();
  const hideNavbar = location.pathname === "/login";

  return !hideNavbar ? <Navbar /> : null;
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <NavbarWrapper />

        <Routes>
          <Route path="/" element={<Home />} />

          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />

          <Route
            path="/nivel"
            element={
              <ProtectedRoute>
                <NivelAgua />
              </ProtectedRoute>
            }
          />

          <Route
            path="/graficos"
            element={
              <ProtectedRoute>
                <Graficos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/perfil"
            element={
              <ProtectedRoute>
               <Perfil />
              </ProtectedRoute>
  }
/>


          <Route path="/login" element={<LoginPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

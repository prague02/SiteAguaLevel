import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FiArrowLeft } from "react-icons/fi";
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend
} from "chart.js";

import { Line } from "react-chartjs-2";

// REGISTRO GLOBAL (IMPORTANTE: fica fora do componente!)
ChartJS.register(
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend
);

const AIO_KEY = "aio_LcGH81b9YE3inUhC21nXOAS7GzLY";
const USERNAME = "XxRibeBRxX";
const FEED_KEY = "nivel-porcentagem";

export default function Graficos() {
  const [dados, setDados] = useState([]);

  async function carregarDados() {
    try {
      const url = `https://io.adafruit.com/api/v2/${USERNAME}/feeds/${FEED_KEY}/data?limit=20`;

      const res = await fetch(url, {
        headers: { "X-AIO-Key": AIO_KEY }
      });

      const json = await res.json();

      const dadosFormatados = json.map((item) => ({
        valor: Number(item.value),
        horario: new Date(item.created_at).toLocaleTimeString("pt-BR")
      }));

      setDados(dadosFormatados.reverse());
    } catch (error) {
      console.error("Erro ao carregar gráfico:", error);
    }
  }

  useEffect(() => {
    carregarDados();
  }, []);

  const data = {
    labels: dados.map((d) => d.horario),
    datasets: [
      {
        label: "Nível da Água (%)",
        data: dados.map((d) => d.valor),
        borderColor: "#4f8bff",
        backgroundColor: "rgba(79, 139, 255, 0.3)",
        borderWidth: 2,
        tension: 0.4,
        pointRadius: 4
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: { min: 0, max: 100 }
    }
  };

  return (
    <div className="page-container">
      <div className="card">

        <div className="seta-wrapper">
 <Link to="/dashboard" className="seta-voltar">
  <FiArrowLeft size={22} />
</Link>

</div>

        <h1 className="titulo">Gráficos</h1>

        <div style={{ height: "260px" }}>
          {dados.length === 0 ? (
            <p>Carregando dados...</p>
          ) : (
            <Line data={data} options={options} />
          )}
        </div>

        <button className="botao botao-primario" onClick={carregarDados}>
          Atualizar Gráfico
        </button>

      </div>
    </div>
  );
}

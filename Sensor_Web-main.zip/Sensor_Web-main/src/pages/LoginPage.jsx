import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");

  async function handleLogin(e) {
    e.preventDefault();
    setErro("");

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, senha);

      // usuário logou → salva no AuthContext
      login({
        uid: userCredential.user.uid,
        email: userCredential.user.email
      });

      navigate("/dashboard");
    } catch (error) {
      if (error.code === "auth/invalid-credential") {
        setErro("Email ou senha incorretos.");
      } else {
        setErro("Erro ao fazer login.");
      }
    }
  }

  return (
    <div className="login-container">
      <form className="login-card" onSubmit={handleLogin}>

        <h2>Bem-vindo!</h2>
        
        {erro && <p className="login-error">{erro}</p>}

        <input 
          type="email" 
          placeholder="Seu email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <input 
          type="password" 
          placeholder="Sua senha"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          required
        />

        <button type="submit">Entrar</button>

      </form>
    </div>
  );
}

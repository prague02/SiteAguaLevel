import { Link } from "react-router-dom";
import React from "react";
import monitoramento from "../assets/monitoramento.png";

export default function Home() {
  return (
    <div className="home-wrapper">

      {/* HERO SECTION */}
      <section
        className="hero"
        style={{
          backgroundImage: `url(${monitoramento})`,
        }}
      >
        <div className="hero-overlay"></div>

        <div className="hero-content">
          <h1>Controle Total da Sua Caixa d’Água</h1>

          <p>
            Monitore o nível em tempo real, visualize gráficos e receba alertas automáticos diretamente no seu painel.
          </p>

          <Link to="/dashboard" className="hero-button">
            Acessar Painel
          </Link>
        </div>

        {/* IMAGEM EXIBIDA SOMENTE NO MOBILE */}
        <img className="hero-mobile-img" src={monitoramento} alt="Monitoramento" />

      </section>

      {/* ABOUT SECTION */}
      <section className="about-section">
        <div className="home-container about-content">

          <img
            src="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?q=80"
            alt="Caixa d'água"
            className="about-image"
          />

          <div className="about-text">
            <h2>Sobre o Sistema</h2>

            <p>
              O AquaLevel é um sistema inteligente de monitoramento de nível da caixa d’água,
              projetado para oferecer controle total de forma prática e acessível.
              Ele utiliza sensores conectados que enviam dados em tempo real para seu painel.
            </p>

            <p>
              Ideal para residências, condomínios, empresas e qualquer lugar que precise
              garantir abastecimento constante sem desperdício.
            </p>
          </div>

        </div>
      </section>

      {/* FEATURES SECTION */}
      <section className="features-section">
        <h2 className="features-title">Recursos do Sistema</h2>

        <div className="features-grid">
          <div className="feature-card">
            <h3>Monitoramento em Tempo Real</h3>
            <p>Veja o nível atualizado da sua caixa d’água a qualquer momento.</p>
          </div>

          <div className="feature-card">
            <h3>Gráficos Detalhados</h3>
            <p>Analise o histórico e o consumo da água com gráficos completos.</p>
          </div>

          <div className="feature-card">
            <h3>Alertas Automáticos</h3>
            <p>Receba alertas quando o nível estiver baixo ou em situações críticas.</p>
          </div>

          <div className="feature-card">
            <h3>Aplicativo Mobile</h3>
            <p>Acompanhe os níveis, gráficos e alertas diretamente pelo app no seu celular.</p>
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="cta-section">
        <h2>Comece a Monitorar Agora Mesmo</h2>

        <p>Crie sua conta ou acesse o painel para visualizar seus dados.</p>

        <Link to="/dashboard" className="cta-button">
          Ir para o Painel
        </Link>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <p>© {new Date().getFullYear()} AquaLevel — Todos os direitos reservados.</p>
      </footer>

    </div>
  );
}

// src/pages/Dashboard.jsx
import React from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.png"; // coloque a logo na pasta /assets

export default function Dashboard() {
  return (
    <div className="dashboard-container">

      {/* LOGO */}
      <img src={logo} alt="Logo" className="dashboard-logo" />

      {/* TÍTULOS */}
      <h1 className="dashboard-title">Painel do Sistema</h1>
      <p className="dashboard-subtitle">
        Escolha uma função para começar.
      </p>

      {/* CARDS */}
      <div className="dashboard-cards">

        <Link to="/nivel" className="dashboard-card">
          <h3>Nível da Água</h3>
          <p>Veja o nível em tempo real.</p>
        </Link>

        <Link to="/graficos" className="dashboard-card">
          <h3>Gráficos</h3>
          <p>Acompanhe o histórico de consumo.</p>
        </Link>

        <Link to="/perfil" className="dashboard-card">
          <h3>Perfil</h3>
          <p>Gerencie sua conta e configurações.</p>
        </Link>

      </div>
    </div>
  );
}

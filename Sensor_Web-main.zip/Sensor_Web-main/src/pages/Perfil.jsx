import { useAuth } from "../context/AuthContext";
import { useState } from "react";
import { EmailAuthProvider, reauthenticateWithCredential, updatePassword } from "firebase/auth";

export default function Perfil() {
  const { user, logout } = useAuth();   // <-- PEGAR logout também

  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");

  async function alterarSenha() {
    if (!senhaAtual || !novaSenha) {
      alert("Preencha todos os campos!");
      return;
    }

    if (novaSenha.length < 6) {
      alert("A nova senha deve ter pelo menos 6 caracteres.");
      return;
    }

    try {
      // Reautenticar o usuário
      const credencial = EmailAuthProvider.credential(
        user.email,
        senhaAtual
      );

      await reauthenticateWithCredential(user, credencial);

      // Alterar senha
      await updatePassword(user, novaSenha);

      alert("Senha alterada com sucesso!");
      setSenhaAtual("");
      setNovaSenha("");

    } catch (err) {
      console.error(err);

      if (err.code === "auth/wrong-password") {
        alert("Senha atual incorreta.");
      } else if (err.code === "auth/weak-password") {
        alert("A nova senha é muito fraca.");
      } else {
        alert("Erro ao alterar a senha.");
      }
    }
  }

  return (
    <div className="perfil-container">
      <div className="perfil-card">
        <h1>Meu Perfil</h1>

        <div className="perfil-group">
          <label>Email</label>
          <input value={user.email} disabled />
        </div>

        <div className="perfil-group">
          <label>Senha atual</label>
          <input
            type="password"
            placeholder="Digite sua senha atual"
            value={senhaAtual}
            onChange={(e) => setSenhaAtual(e.target.value)}
          />
        </div>

        <div className="perfil-group">
          <label>Nova senha</label>
          <input
            type="password"
            placeholder="Digite a nova senha"
            value={novaSenha}
            onChange={(e) => setNovaSenha(e.target.value)}
          />
        </div>

        {/* Alterar senha */}
        <button onClick={alterarSenha} className="perfil-save">
          Alterar senha
        </button>

        {/* Sair */}
        <button onClick={logout} className="perfil-sair">
          Sair
        </button>
      </div>
    </div>
  );
}

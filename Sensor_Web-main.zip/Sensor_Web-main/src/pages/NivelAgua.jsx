import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FiArrowLeft } from "react-icons/fi"; // ← Import da seta
import { getNivelPercentual } from "../services/adafruit";


export default function NivelAgua() {
  const [nivel, setNivel] = useState(0);
  const [alerta, setAlerta] = useState(false);
  const navigate = useNavigate();

  async function atualizarNivel() {
    try {
      const valor = await getNivelPercentual();
      setNivel(valor);

      setAlerta(valor < 30); // alerta ativo se < 30%
    } catch (error) {
      console.error("Erro ao buscar nível:", error);
      setNivel(0);
      setAlerta(true);
    }
  }

  // Atualiza automaticamente ao abrir a página
  useEffect(() => {
    atualizarNivel();

    // Atualiza a cada 10s (opcional)
    const intervalo = setInterval(atualizarNivel, 10000);
    return () => clearInterval(intervalo);
  }, []);

  return (
    <div className="page-container">
{/* 🔙 Botão de voltar (padrão da página de gráficos) */}
<button
  onClick={() => navigate(-1)}
  style={{
    position: "absolute",
    top: "240px",   // 🔥 aproximado do card
    left: "750px",  // 🔥 mais próximo do card também
    zIndex: 1000,
    background: "white",
    width: "48px",
    height: "48px",
    borderRadius: "12px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    cursor: "pointer",
    border: "none"
  }}
>
  <FiArrowLeft size={22} color="#333" />
</button>



      <div className="card">
        <h1 className="titulo">Nível da Água</h1>

        {/* ALERTA */}
        {alerta && (
          <div
            style={{
              background: "#ff6b6b",
              color: "white",
              padding: "12px",
              borderRadius: "12px",
              marginBottom: "18px",
              fontWeight: "600",
            }}
          >
            ⚠️ Atenção: Nível baixo! Verifique a caixa d’água.
          </div>
        )}

        {/* Barra de água */}
        <div className="barra-agua-container">
          <div className="barra-agua" style={{ height: `${nivel}%` }}></div>
        </div>

        {/* Valor numérico */}
        <div className="sensor-valor">{nivel}%</div>
      </div>
    </div>
  );
}

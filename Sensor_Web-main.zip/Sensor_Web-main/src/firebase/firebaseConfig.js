// Importando módulos do Firebase
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getDatabase } from "firebase/database"; // só se for usar Realtime Database

// Configuração do Firebase (a sua)
const firebaseConfig = {
  apiKey: "AIzaSyD4c4L3N_PferHGZjzHLp7vV9D6yMuOeNY",
  authDomain: "appagua-2204c.firebaseapp.com",
  projectId: "appagua-2204c",
  storageBucket: "appagua-2204c.firebasestorage.app",
  messagingSenderId: "920462606998",
  appId: "1:920462606998:web:3c640e03b349bbbad7b8b7"
};

// Inicializa o app
const app = initializeApp(firebaseConfig);

// Exporta os serviços que você vai usar no seu projeto
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const rtdb = getDatabase(app); // opcional — apenas se quiser RTDB

export default app;

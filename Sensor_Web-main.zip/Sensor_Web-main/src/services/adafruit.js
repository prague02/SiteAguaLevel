const AIO_KEY = "aio_LcGH81b9YE3inUhC21nXOAS7GzLY";
const USERNAME = "XxRibeBRxX";

export async function getNivelPercentual() {
  const url = `https://io.adafruit.com/api/v2/${USERNAME}/feeds/nivel-porcentagem/data/last`;

  const res = await fetch(url, {
    headers: { "X-AIO-Key": AIO_KEY }
  });

  const data = await res.json();
  return Number(data.value);
}

export async function getNivelDistancia() {
  const url = `https://io.adafruit.com/api/v2/${USERNAME}/feeds/nível-distancia/data/last`;

  const res = await fetch(url, {
    headers: { "X-AIO-Key": AIO_KEY }
  });

  const data = await res.json();
  return Number(data.value);
}

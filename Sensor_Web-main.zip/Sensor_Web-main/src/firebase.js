import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyD4c4L3N_PferHGZjzHLp7vV9D6yMuOeNY",
  authDomain: "appagua-2204c.firebaseapp.com",
  projectId: "appagua-2204c",
  storageBucket: "appagua-2204c.firebasestorage.app",
  messagingSenderId: "920462606998",
  appId: "1:920462606998:web:3c640e03b349bbbad7b8b7"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

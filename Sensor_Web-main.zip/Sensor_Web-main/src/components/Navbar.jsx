// src/components/Navbar.jsx
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useState } from "react";
import { FaUserCircle } from "react-icons/fa";
import logo from "../assets/logo.png"; // voltou a logo 😉

export default function Navbar() {
  const { user } = useAuth?.() || {};
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="navbar-wrapper">
      <div className="navbar-container">

       {/* ESQUERDA → Logo + Nome */}
<div className="navbar-left">
  <img
    src={logo}
    alt="Logo"
    className="navbar-logo-img"
  />
  <span className="navbar-title">AquaLevel</span>
</div>


        {/* CENTRO → Menu */}
        <ul className="navbar-links center-menu">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/dashboard">Dashboard</Link></li>
          <li><Link to="/graficos">Gráficos</Link></li>
          <li><Link to="/nivel">Nível</Link></li>
        </ul>

        {/* DIREITA → Ícone Perfil */}
        <div className="navbar-right">
          {user ? (
            <Link to="/perfil" className="profile-icon-btn">
              <FaUserCircle size={26} />
            </Link>
          ) : (
            <Link to="/login" className="profile-icon-btn">
              Login
            </Link>
          )}
        </div>

        {/* BOTÃO MOBILE */}
        <button
          className={`menu-btn ${menuOpen ? "open" : ""}`}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span></span><span></span><span></span>
        </button>
      </div>

      {/* MENU MOBILE */}
      <nav className={`mobile-menu ${menuOpen ? "open" : ""}`}>
        <ul>
          <li onClick={() => setMenuOpen(false)}><Link to="/">Home</Link></li>
          <li onClick={() => setMenuOpen(false)}><Link to="/dashboard">Dashboard</Link></li>
          <li onClick={() => setMenuOpen(false)}><Link to="/graficos">Gráficos</Link></li>
          <li onClick={() => setMenuOpen(false)}><Link to="/nivel">Nível</Link></li>
          {user ? (
            <li onClick={() => setMenuOpen(false)}><Link to="/perfil">Perfil</Link></li>
          ) : (
            <li onClick={() => setMenuOpen(false)}><Link to="/login">Login</Link></li>
          )}
        </ul>
      </nav>
    </header>
  );
}

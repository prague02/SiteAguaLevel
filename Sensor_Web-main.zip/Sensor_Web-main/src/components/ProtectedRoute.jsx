import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();

  // Enquanto o Firebase ainda está verificando o usuário
  if (loading) {
    return (
      <div style={{
        textAlign: "center",
        paddingTop: "40px",
        fontSize: "18px",
        color: "#555"
      }}>
        Carregando...
      </div>
    );
  }

  // Se não estiver logado → manda para o login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
